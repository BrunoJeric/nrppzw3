<template>
    <div>
        <p>404 PAGE NOT FOUND</p>
    </div>
</template>