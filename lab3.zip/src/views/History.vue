<template>
  <div class="history">
    <HistoryComponent/>
  </div>
</template>

<script>
import HistoryComponent from '@/components/HistoryComponent.vue'

export default {
  name: 'History',
  components: {
    HistoryComponent
  }
}
</script>

